function store(key, value){
    localStorage.setItem(key, value);
}

function retrieve(key){
    return localStorage.getItem(key);
}

document.addEventListener('DOMContentLoaded', function() {

    // Initalize Drawer Trigger
    var appDrawer = document.querySelectorAll('.fixed-action-btn');
    var drawerInstance = M.FloatingActionButton.init(appDrawer, {
        hoverEnabled: true
    });
    updateDrawerSettings(drawerInstance);

    // Most Visited
    var dropdown = document.querySelectorAll('.dropdown-trigger');
    var dropDownInstances = M.Dropdown.init(dropdown, {
        hover: true
    });

});

setBackground();
startTime();
addGreeting();
initCountdown();
initTopSites();
populateApps();


// Analytics
try{
    checkUser();
}catch(e){}