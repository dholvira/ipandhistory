function store(key, value){
    localStorage.setItem(key, value);
}

function retrieve(key){
    return localStorage.getItem(key);
}

//Top Sites
if(retrieve("topSites") == "true"){
    document.getElementById("toggleTopSites").checked = true;
}
document.getElementById("toggleTopSites").addEventListener("change", changeTopSitesState);

// App Drawer
appListPopulate();
if(retrieve("drawerAlwaysOpen") == "true"){
    document.getElementById("drawerAlways").checked = true;
}
if(retrieve("appDrawer") == "true"){
    document.getElementById("toggleAppDrawer").checked = true;
}
document.getElementById("alwaysOpenForm").addEventListener("change", alwaysOpenUpdate);
document.getElementById("toggleAppDrawer").addEventListener("change", changeAppDrawerState);


// Daily Wallpaper
if(retrieve("backgroundPaused") === null){
    store("backgroundPaused", "false");
}
if(retrieve("backgroundPaused") == "false"){
    document.getElementById("bgPause").checked = true;
}
document.getElementById("changeWallpaperDialy").addEventListener("change", changeWallpaperDialy);


// Time Format
var timeFormatForm = document.getElementById("timeFormatForm");
var timeFormatCB = timeFormatForm.querySelectorAll("input[type='radio']");
if(retrieve("timeFormat") == "24"){
    timeFormatCB[1].checked = true;
}else{
    timeFormatCB[0].checked = true;
}
document.getElementById("timeFormatForm").addEventListener("change", timeFormatUpdate);



// Analytics
try{
    eventAnalytics("settings");
}catch(e){}


// Countdown

if(retrieve("countdown") === null || retrieve("countdownDate") === null || retrieve("countdownText") === null){
        
    store("countdown", "");
    store("countdownText", "");
    store("countdownDate", "");
}

document.getElementById("cdControl").addEventListener("change", changeCountdownState);
document.getElementById("cdText").addEventListener("input", updateCountdownText);

document.addEventListener('DOMContentLoaded', function() {
    var datepickers = document.querySelectorAll('.datepicker');
    var datepickerInstances = M.Datepicker.init(datepickers, {
        format: "dd mmm, yyyy",
        firstDay: 1,
        onClose: updateDate
    });
    
    var instance = M.Datepicker.getInstance(document.getElementById("cdDate"));
    instance.setDate(new Date(retrieve("countdownDate")));

    if(retrieve("countdown") == "true"){
        document.getElementById("cdControl").checked = true;
        document.getElementById("cdDate").disabled = false;
        document.getElementById("cdText").disabled = false;
        document.getElementById("cdText").value = retrieve("countdownText");
    }

});


// Greetings
document.getElementById("changeNameButton").addEventListener("click", changeName);
if(retrieve("greeting") === null){
    store("greeting", "true");
}

if(retrieve("greeting") == "true"){
    document.getElementById("grtControl").checked = true;
}

document.getElementById("grtControl").addEventListener("change", changeGreetingsState);
