var allApps = {
    "account": "https://myaccount.google.com/",
    "calendar": "https://www.google.com/calendar/",
    "docs": "https://docs.google.com/document/",
    "drive": "https://drive.google.com/",
    "dropbox": "https://www.dropbox.com/",
    "facebook": "https://facebook.com",
    "gmail": "https://mail.google.com/",
    "googleplus": "https://plus.google.com/",
    "instagram": "https://www.instagram.com/",
    "keep": "https://keep.google.com",
    "linkedin": "https://www.linkedin.com/",
    "maps": "https://www.google.com/maps",
    "news": "https://news.google.com/",
    "photos": "https://photos.google.com/",
    "quora": "https://www.quora.com/",
    "reddit": "https://www.reddit.com/",
    "sheets": "https://sheets.google.com",
    "skype": "https://www.skype.com/",
    "slides": "https://slides.google.com",
    "translate": "https://translate.google.com/",
    "trello": "https://trello.com/",
    "tumblr": "https://www.tumblr.com/",
    "twitter": "https://twitter.com/",
    "whatsapp": "https://web.whatsapp.com/",
    "wikipedia": "https://www.wikipedia.org/",
    "yahoo": "https://www.yahoo.com",
    "youtube": "https://www.youtube.com/"
}

function populateApps() {

    if(retrieve("myApps") === null){
        
        //Default Apps
        var myAppsDefaults = ["calendar", "drive", "facebook", "gmail", "instagram", "news", "twitter", "youtube"];
        myAppsString = JSON.stringify(myAppsDefaults);
        store("myApps", myAppsString);
    }

    if(retrieve("appDrawer") === null){
        store("appDrawer", true);
    }

    if(retrieve("appDrawer") == "true"){
        document.getElementById("app-drawer").classList.remove("hide");
    }else{
        document.getElementById("newsTrigger").style.right = "24px";
    }
    
    var myApps = JSON.parse(retrieve("myApps"));   
    
    for(key in myApps){

        var list = document.getElementById("appList");
        
        var liE = document.createElement("LI");
        liE.setAttribute("id", myApps[key]);
        list.appendChild(liE);

        var li =document.getElementById(myApps[key]);
        li.innerHTML = "<a class='btn-floating' href='" + allApps[myApps[key]] + "'><img src='./images/icons/apps/" + myApps[key] + ".png'></a>"
    }
}

function updateDrawerSettings(drawerInstance){
    if(retrieve("drawerAlwaysOpen") === null){
        store("drawerAlwaysOpen", "false");
    }
    
    if(retrieve("drawerAlwaysOpen") == "true"){
        drawerInstance[0].open()
    }
}


// SETTINGS
function changeAppDrawerState(){
    var cb = document.getElementById("toggleAppDrawer");

    if(cb.checked){
        store("appDrawer", "true");
    }else{
        store("appDrawer", "false");     
    }
}

function appListValidate(action){
    
    var appList = document.getElementById("appList");
    var checkboxes = appList.querySelectorAll("input[type='checkbox']");

    if(action == 'enable'){

        for(key in checkboxes){
            if(checkboxes[key].checked === false){
                checkboxes[key].removeAttribute("disabled");
            }
        }

    }else{

        for(key in checkboxes){
            if(checkboxes[key].checked === false){
                checkboxes[key].setAttribute("disabled", "disabled");
            }
        }
    }
}

function appListPopulate(){

    var appList = document.getElementById("appList");
    var myApps = JSON.parse(retrieve("myApps"));   

    for(key in allApps){
        var checked = '';
        for(app in myApps){
            if(key == myApps[app]){
                checked = 'checked';
            }
        }
        appList.innerHTML += "<div class='col s4'><label><input type='checkbox' id='" + key + "' " + checked + " /><span><img src='./images/icons/apps/" + key + ".png'>" + key.charAt(0).toUpperCase() + key.slice(1) + "</span></label></div>";
    }

    var count = appList.querySelectorAll('input[type="checkbox"]:checked').length;
    document.getElementById("appListCount").innerText = count + "/8 Apps Selected";
    if(count == 8){
        appListValidate('disable');
    }

    document.getElementById("appList").addEventListener("change", appListUpdate);
}

function appListUpdate(){
    var appList = document.getElementById("appList");
    var count = appList.querySelectorAll('input[type="checkbox"]:checked').length;
    document.getElementById("appListCount").innerText = count + "/8 Apps Selected";

    if(count == 8){
        appListValidate("disable");
    }else{
        appListValidate("enable");
    }

    var apps = appList.querySelectorAll('input[type="checkbox"]:checked');

    var myApps = [];
    
    for(key in apps){
        if(apps[key].checked === true){
            myApps.push(apps[key].id); 
        }
    }

    myApps = JSON.stringify(myApps);
    
    store("myApps", myApps);
}

function alwaysOpenUpdate(){
    var cb = document.getElementById("drawerAlways");
    
    if(cb.checked === true){
        store("drawerAlwaysOpen", "true");
    }else{
        store("drawerAlwaysOpen", "false");
    }
}