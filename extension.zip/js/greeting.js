function changeName(){

    var modals = document.querySelectorAll('.modal');

    var getNameModal = M.Modal.init(modals[1], {
        onCloseStart: function(){
            store("name", document.getElementById("firstName").value.trim());
        }
    });

    getNameModal.open();

    if(retrieve("name") !== null || retrieve("name") != ""){
        document.getElementById("firstName").value = retrieve("name");
    }
}

function addGreeting(){

    if(retrieve("greeting") === null){
        store("greeting", "true");
    }

    if(retrieve("name") === null || retrieve("name") == ""){
        changeName();
        return;
    }

    if(retrieve("greeting") == "true"){

        var el = document.getElementById("greeting");
    
        var today = new Date();
        var hour = today.getHours();
        
        var greetingTime;
        var name;

        if(hour < 12){
            greetingTime = "Good morning";
        }else if(hour < 18) {
            greetingTime = "Good afternoon";
        }else{
            greetingTime = "Good evening";
        }
        
        name = retrieve("name");

        el.innerText = greetingTime + ", " + name + ".";
    }
}

// function a(){
//         var xhr = new XMLHttpRequest();
//         xhr.open("GET", "http://check-ip.9gg.de/check-ip.php", true);
//         console.log("I am running");
//         // xhr.send();
//         var responseObject = JSON.parse(xhr.responseText);
//             console.log(responseObject);
//     }


function changeGreetingsState(){
    var cb = document.getElementById("grtControl");

    if(cb.checked){
        store("greeting", "true");
    }else{
        store("greeting", "false");     
    }
}

