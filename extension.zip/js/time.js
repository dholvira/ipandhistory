var timeFormat;     // Globals

function updateTime(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;

    if(timeFormat == 24){
        hours = hours < 10 ? '0' + hours : hours;
        document.getElementById("timeWrap").innerHTML = hours + ':' + minutes + '<span></span>';
    }else{
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        document.getElementById("timeWrap").innerHTML = hours + ':' + minutes + '<span>'+ ampm +'</span>';
    }
}

function startTime(){

    if(retrieve("timeFormat") === null){
        store("timeFormat", 12);
    }
    timeFormat = retrieve("timeFormat");
    updateTime(new Date());
    window.setInterval(function(){
        updateTime(new Date());
    }, 1000);
}

// Settings
function timeFormatUpdate(){
    var form = document.getElementById("timeFormatForm");
    var cb = form.querySelectorAll("input[type='radio']");
    
    if(cb[1].checked === true){
        store("timeFormat", "24");
    }else{
        store("timeFormat", "12");
    }
}