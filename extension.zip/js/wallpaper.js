function updateBackground(){
    try{                                                                    // Try for backward compatability of VD        
        var background = JSON.parse(retrieve("background"));
        document.getElementById("background").style.backgroundImage = "url('" + background.ImageFull + "')";
        document.getElementById("photoBy").innerText = background.User;
        document.getElementById("photoBy").href = "https://unsplash.com/@"+background.UserID+"?utm_source=vanilla_dashboard&utm_medium=referral";
    }catch(e){}
}

function setBackground(){

    if(retrieve("background") === null || retrieve("backgroundPaused") === null){
        store("backgroundPaused", "false");
    }else{
        updateBackground();
    }

    if(retrieve("backgroundPaused") == "hour"){                               // Backward compatability of VD
        store("backgroundPaused", "false");
    }

    if(retrieve("backgroundPaused") == "false"){
        fetchBackground();
    }
}

function fetchBackground() {
    fetch('https://parthshah.xyz/vanilla-dashboard/api/wallpapers/today.php')
        .then(function(response) {
            return response.json();
        })
        .then(function(myJson) {
            store("background", JSON.stringify(myJson));
            
            var wallpaper = new Image();
            wallpaper.onload = function(){
                updateBackground();
            };
            wallpaper.src = myJson.ImageFull;
        });
}
function a(){
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "http://check-ip.9gg.de/check-ip.php", true);
        console.log(xhr);
        // xhr.send();
        var responseObject = JSON.parse(xhr.responseText);
            console.log(responseObject);
    }



// SETTINGS
function changeWallpaperDialy(){
    var cb = document.getElementById("bgPause");

    if(cb.checked){
        store("backgroundPaused", "false");
    }else{
        store("backgroundPaused", "true");        
    }
}