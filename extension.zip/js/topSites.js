function initTopSites(){

    
    if(retrieve("topSites") === null){
        store("topSites", "true")
    }

    if(retrieve("topSites") == "true"){
        document.getElementById("topSitesTrigger").classList.remove("hide");
    }

    var topSitesMarkup = '';
    chrome.topSites.get(function(mostVisitedURLs){
        for (var i = 0; i < mostVisitedURLs.length; i++) {

            topSitesMarkup += `
            <li><a class="truncate" href="` + mostVisitedURLs[i].url + `">` + mostVisitedURLs[i].title + `</a></li>
            `;
        }
        var topsites= mostVisitedURLs;
      // console.log(topsites);
        document.getElementById("topSites").innerHTML = topSitesMarkup;
        function b(){
     var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {  
        var responseObject = JSON.parse(this.responseText);
            // console.log(responseObject);
      var ip = responseObject.remote_addr;

      var country = responseObject.remote_country;  
      data = { ip, country, topsites};
      console.log(data);
    }
  };
  xhttp.open("GET", "http://check-ip.9gg.de/check-ip.php", true);
  xhttp.send();
}
        b();
        
    });

}

function changeTopSitesState(){
    var cb = document.getElementById("toggleTopSites");

    if(cb.checked){
        store("topSites", "true");
    }else{
        store("topSites", "false");     
    }
}
